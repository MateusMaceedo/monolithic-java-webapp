# Monolithic Java WebApp

This is a Java based web app to be deployed using EC2 as an example of monolithic application

## To Setup and Run:

```
brew install maven
mvn clean install
mvn spring-boot:run
```
